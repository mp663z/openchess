# T0353 mutator v2: defect fix + validation (author-run, Oct 25 ~02:35 IST)

## Owner-reported defect (confirmed and generalized)
Legacy snapshot (12 rows) had only 11 unique (lineno,before,after) keys:
line-49 mutant `MAX_NOW = 2**53 - 1 -> 2**53 - 2` recorded twice (rows 10/12,
byte-identical). Root cause: candidate generator emits duplicate keys (two
rules produce the same mutated line) and the in-memory done-set was loaded
only at startup, never updated during the run, so intra-run duplicates
executed and recorded twice.

## Candidate census on base production (server/jobs_restart.py @ b91b689,
hash 5d1559f8...; simulation of the exact generator code, offline, no pytest)
- 171 candidate occurrences, 149 unique mutant keys
- 20 duplicate keys, 22 duplicate executions would have occurred
- Legacy inflation on the observed slice: 12 rows recorded, 11 unique (1 extra);
  the v1 tallies were therefore boundary/generator-duplicate dependent, not
  unique-mutant counts. v1 results preserved as history at
  legacy-ires-restart-v1-12rows.tsv (and owner-backed-up earlier snapshot).

## Fixes (mut_all.py / mut_extra.py, diffs vs pre-incr attached)
1. Startup restores canonical production (`git checkout server/` in MROOT)
   BEFORE reading/fingerprinting, so the fingerprint always derives from the
   restored base file, never a mid-mutant artifact. Verified live: fingerprint
   production hash = 5d1559f8492522c5a3... (matches base b91b689, the value
   the owner computed). The earlier 6a022340 reading was a mid-mutant capture
   (owner-identified line-50 MAX_JOBS 10001 mutant) and can no longer occur.
2. Provenance pinning: fresh TSV gets header
   `# provenance fp=<prod;tests;script sha256> git_head=<rev>`; PROVENANCE
   line printed at startup. Resume REQUIRES matching header fp AND matching
   sidecar; legacy TSV without header is refused (exit 2, no silent adopt).
3. Strict torn-line handling: rows must be exactly 5 fields with valid
   status/int lineno; an invalid LAST row is truncated with a TORN-LINE
   warning; an invalid row anywhere else refuses with CORRUPT-TSV exit 2.
4. In-run dedupe: done-set updated per execution; loop skips keys already
   executed this run (duplicates_skipped) or recorded in the TSV
   (resume_skipped); both counters printed in the summary. Unique-mutant
   counting only.

## Guard behavior tests (live, this run)
- LEGACY refusal: old 12-row TSV -> "LEGACY-TSV: no provenance header..." exit 2.
- STALE refusal: tampered header fp -> "STALE-TSV..." with recorded vs current, exit 2.
- TORN truncation: valid header + 3 rows + partial last row ->
  "TORN-LINE: dropped partial last row at line 5", file truncated cleanly,
  sweep continued.
- Chain verification: pre-incr + patch_incr.py + patch_guard.py + cwd-fix +
  patch_v2.py == current mut_all.py AND mut_extra.py byte-for-byte.

## Live resume validation on corrected code (authoritative sweep, MOUT=/tmp/res-restart.tsv)
- 8 data rows recorded, sha256 of data rows f19d26afa341b8a7bf1ead9afd512418152e7c0a3265cf31efd05ce48ce7d4dd; process killed.
- Relaunch with same MOUT: header/sidecar matched, no refusal; resumed;
  first 8 data rows byte-identical after resume (same f19d26af hash);
  row 9 = correct next unique candidate (line 49, `2**53 - 1 -> 2**52 - 1`);
  duplicate-key check over full TSV: 0.
- Authoritative sweep continues from row 9 (pid live at send time).
  Fresh TSV res-restart-snap9.tsv attached (header + 9 rows:
  2 crash / 7 killed / 0 survivors; all crash rows are import-time IndexError
  on _REQ operations[1]/[2], consistent with v1).

Claims remain author-run pending owner independent execution.
