import re,subprocess,sys,shutil,os
mod,tests=sys.argv[1],sys.argv[2:]
import os
root=os.environ.get("MROOT","/home/sandbox/openchess/")
p=root+f"server/{mod}.py"
mout=os.environ.get("MOUT")
if mout:
    subprocess.run(["git","checkout","server/"],cwd=root,check=True,capture_output=True)
src=open(p).read().split("\n")
import hashlib
def _sha(path):
    return hashlib.sha256(open(path,"rb").read()).hexdigest()
fp=";".join([_sha(p)]+[_sha(t if os.path.isabs(t) else os.path.join(root,t)) for t in tests]+[_sha(os.path.abspath(__file__))])
mout=os.environ.get("MOUT")
fp_path=mout+".fp" if mout else None
if mout:
    head=subprocess.run(["git","rev-parse","HEAD"],cwd=root,capture_output=True,text=True).stdout.strip()
    prov=f"# provenance fp={fp} git_head={head}"
    if os.path.exists(mout):
        first=open(mout).readline().rstrip("\n")
        if not first.startswith("# provenance fp="):
            sys.stderr.write("LEGACY-TSV: no provenance header; refusing to resume against unknown inputs\n")
            sys.exit(2)
        rec=first[len("# provenance fp="):].split(" git_head=")[0]
        if rec!=fp:
            sys.stderr.write("STALE-TSV: inputs changed since the results file was written; refusing to resume\n")
            sys.stderr.write(f"recorded {rec}\ncurrent  {fp}\n")
            sys.exit(2)
        if not os.path.exists(fp_path) or open(fp_path).read().strip()!=fp:
            sys.stderr.write("STALE-SIDECAR: sidecar missing or mismatched; refusing to resume\n")
            sys.exit(2)
        open(fp_path,"w").write(fp)
    else:
        open(mout,"w").write(prov+"\n")
        open(fp_path,"w").write(fp)
    print("PROVENANCE",prov[2:])
swaps=[("is not None","is not 0"),("is None","is 0"),(" is not "," is "),(" is "," is not "),("fullmatch","match"),(" in "," not in "),(" not in "," in "),("None","0"),("True","False"),("False","True"),("type(","isinstance(")]
swaps=[x for x in swaps if isinstance(x,tuple)]
start=next(i for i,l in enumerate(src) if l.startswith("_CC ="))
indoc=False
mout=os.environ.get("MOUT")
done=set()
if mout and os.path.exists(mout):
    _raw=open(mout).read().split("\n")
    if _raw and _raw[-1]=="": _raw.pop()
    _bad=-1
    for _idx,_line in enumerate(_raw):
        if _line.startswith("#"): continue
        _p=_line.split("\t")
        if len(_p)==5 and _p[1] in ("killed","crash","survivor") and _p[0].isdigit():
            done.add((int(_p[0]),_p[2],_p[3]))
        else:
            _bad=_idx
    if _bad>=0:
        if _bad!=len(_raw)-1:
            sys.stderr.write(f"CORRUPT-TSV: invalid row at line {_bad+1}; refusing\n")
            sys.exit(2)
        sys.stderr.write(f"TORN-LINE: dropped partial last row at line {_bad+1}\n")
        with open(mout,"w") as _f: _f.write("\n".join(_raw[:_bad])+"\n")
pres=set(done)
def emit(i,l,nl,status,detail):
    if not mout: return
    detail=str(detail).replace("\t"," ").replace("\n"," ")[:80]
    with open(mout,"a") as f:
        f.write(f"{i+1}\t{status}\t{l.strip()}\t{nl.strip()}\t{detail}\n")
        f.flush(); os.fsync(f.fileno())
surv=[];tot=0;crash=[];sem=0;dupes=0;resumed=0
for i in range(start,len(src)):
    l=src[i]
    st=l.strip()
    if indoc:
        if '"""' in st: indoc=False
        continue
    if st.startswith('"""'):
        if not (st.count('"""')>=2): indoc=True
        continue
    if st.startswith("#"): continue
    code=l.split("  # ")[0]
    cands=list(swaps)
    l=code
    for a,b in cands:
        for m in re.finditer(re.escape(a),l):
            nl=l[:m.start()]+b+l[m.end():]
            if nl==l: continue
            if (i+1,l.strip(),nl.strip()) in done:
                if (i+1,l.strip(),nl.strip()) in pres: resumed+=1
                else: dupes+=1
                continue
            done.add((i+1,l.strip(),nl.strip()))
            tot+=1
            new=src[:i]+[nl]+src[i+1:]
            open(p,"w").write("\n".join(new))
            subprocess.run("find . -name __pycache__ -prune -exec rm -rf {} +",shell=True,cwd=root,capture_output=True)
            r=subprocess.run(["/tmp/v/bin/python","-m","pytest","-q","-x","-p","no:cacheprovider"]+tests,cwd=root,capture_output=True,text=True)
            if r.returncode==0:
                surv.append((i+1,l.strip(),nl.strip())); emit(i,l,nl,"survivor","")
            else:
                errs=[x for x in r.stdout.splitlines() if x.startswith("E  ")]
                first=errs[0][1:].strip() if errs else ""
                import re as _re
                if _re.match(r"^(TypeError|KeyError|AttributeError|IndexError|ValueError|RecursionError|NameError|ZeroDivisionError|OverflowError|UnicodeError|RuntimeError|UnicodeEncodeError|UnicodeDecodeError)\b",first):
                    crash.append((i+1,nl.strip(),first[:80])); emit(i,l,nl,"crash",first)
                else:
                    sem+=1; emit(i,l,nl,"killed",first)
open(p,"w").write("\n".join(src))
if mout and os.path.exists(mout):
    rows=[]
    for _l in open(mout):
        _l=_l.rstrip("\n")
        if not _l or _l.startswith("#"): continue
        _r=_l.split("\t")
        if len(_r)!=5 or _r[1] not in ("killed","crash","survivor") or not _r[0].isdigit():
            sys.stderr.write("CORRUPT-TSV at summary: "+_l[:60]+"\n"); sys.exit(2)
        rows.append(_r)
    sa=[_r for _r in rows if _r[1]=="survivor"]; ca=[_r for _r in rows if _r[1]=="crash"]; ka=[_r for _r in rows if _r[1]=="killed"]
    print("mutants",len(rows),"survivors",len(sa),"semantic_kills",len(ka),"crash_only",len(ca),"resume_skipped",resumed,"duplicates_skipped",dupes)
    for _r in ca: print("CRASH",(int(_r[0]),_r[3],_r[4] if len(_r)>4 else ""))
    for _r in sa: print((int(_r[0]),_r[2],_r[3]))
else:
    print("mutants",tot,"survivors",len(surv),"semantic_kills",sem,"crash_only",len(crash))
    for c in crash: print("CRASH",c)
    for s in surv: print(s)
