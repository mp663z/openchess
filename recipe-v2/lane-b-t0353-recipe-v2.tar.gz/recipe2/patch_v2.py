import sys, ast

# A. restore canonical production before reading/fingerprinting
A_OLD = 'src=open(p).read().split("\\n")\nimport hashlib'
A_NEW = '''mout=os.environ.get("MOUT")
if mout:
    subprocess.run(["git","checkout","server/"],cwd=root,check=True,capture_output=True)
src=open(p).read().split("\\n")
import hashlib'''

# B. strict provenance: fresh TSV gets header; resume requires header match + sidecar match; no adopt
B_OLD = '''if mout:
    if os.path.exists(mout):
        if os.path.exists(fp_path):
            old=open(fp_path).read().strip()
            if old!=fp:
                sys.stderr.write("STALE-TSV: inputs changed since the results file was written; refusing to resume\\n")
                sys.stderr.write(f"recorded {old}\\ncurrent  {fp}\\n")
                sys.exit(2)
        else:
            open(fp_path,"w").write(fp)
    else:
        open(fp_path,"w").write(fp)'''
B_NEW = '''if mout:
    head=subprocess.run(["git","rev-parse","HEAD"],cwd=root,capture_output=True,text=True).stdout.strip()
    prov=f"# provenance fp={fp} git_head={head}"
    if os.path.exists(mout):
        first=open(mout).readline().rstrip("\\n")
        if not first.startswith("# provenance fp="):
            sys.stderr.write("LEGACY-TSV: no provenance header; refusing to resume against unknown inputs\\n")
            sys.exit(2)
        rec=first[len("# provenance fp="):].split(" git_head=")[0]
        if rec!=fp:
            sys.stderr.write("STALE-TSV: inputs changed since the results file was written; refusing to resume\\n")
            sys.stderr.write(f"recorded {rec}\\ncurrent  {fp}\\n")
            sys.exit(2)
        if not os.path.exists(fp_path) or open(fp_path).read().strip()!=fp:
            sys.stderr.write("STALE-SIDECAR: sidecar missing or mismatched; refusing to resume\\n")
            sys.exit(2)
        open(fp_path,"w").write(fp)
    else:
        open(mout,"w").write(prov+"\\n")
        open(fp_path,"w").write(fp)
    print("PROVENANCE",prov[2:])'''

# C. strict done-loader: exactly-5-field rows, torn LAST row truncated, corrupt mid file refused
C_OLD = '''done=set()
if mout and os.path.exists(mout):
    for _line in open(mout):
        _p=_line.rstrip("\\n").split("\\t")
        if len(_p)>=4: done.add((int(_p[0]),_p[2],_p[3]))'''
C_NEW = '''done=set()
if mout and os.path.exists(mout):
    _raw=open(mout).read().split("\\n")
    if _raw and _raw[-1]=="": _raw.pop()
    _bad=-1
    for _idx,_line in enumerate(_raw):
        if _line.startswith("#"): continue
        _p=_line.split("\\t")
        if len(_p)==5 and _p[1] in ("killed","crash","survivor") and _p[0].isdigit():
            done.add((int(_p[0]),_p[2],_p[3]))
        else:
            _bad=_idx
    if _bad>=0:
        if _bad!=len(_raw)-1:
            sys.stderr.write(f"CORRUPT-TSV: invalid row at line {_bad+1}; refusing\\n")
            sys.exit(2)
        sys.stderr.write(f"TORN-LINE: dropped partial last row at line {_bad+1}\\n")
        with open(mout,"w") as _f: _f.write("\\n".join(_raw[:_bad])+"\\n")
pres=set(done)'''

# D. in-run dedupe + unique counting
D_OLD = '''            if nl==l: continue
            tot+=1
            if (i+1,l.strip(),nl.strip()) in done: continue'''
D_NEW = '''            if nl==l: continue
            if (i+1,l.strip(),nl.strip()) in done:
                if (i+1,l.strip(),nl.strip()) in pres: resumed+=1
                else: dupes+=1
                continue
            done.add((i+1,l.strip(),nl.strip()))
            tot+=1'''

E_OLD = "surv=[];tot=0;crash=[];sem=0"
E_NEW = "surv=[];tot=0;crash=[];sem=0;dupes=0;resumed=0"

# F. strict summary reader + accounting columns
F_OLD = '''if mout and os.path.exists(mout):
    rows=[_l.rstrip("\\n").split("\\t") for _l in open(mout) if _l.strip()]
    rows=[_r for _r in rows if len(_r)>=4]'''
F_NEW = '''if mout and os.path.exists(mout):
    rows=[]
    for _l in open(mout):
        _l=_l.rstrip("\\n")
        if not _l or _l.startswith("#"): continue
        _r=_l.split("\\t")
        if len(_r)!=5 or _r[1] not in ("killed","crash","survivor") or not _r[0].isdigit():
            sys.stderr.write("CORRUPT-TSV at summary: "+_l[:60]+"\\n"); sys.exit(2)
        rows.append(_r)'''

G_OLD = '''    print("mutants",len(rows),"survivors",len(sa),"semantic_kills",len(ka),"crash_only",len(ca))'''
G_NEW = '''    print("mutants",len(rows),"survivors",len(sa),"semantic_kills",len(ka),"crash_only",len(ca),"resume_skipped",resumed,"duplicates_skipped",dupes)'''

for path in sys.argv[1:]:
    s = open(path).read()
    for name,(o,n) in {"A":(A_OLD,A_NEW),"B":(B_OLD,B_NEW),"C":(C_OLD,C_NEW),"D":(D_OLD,D_NEW),"E":(E_OLD,E_NEW),"F":(F_OLD,F_NEW),"G":(G_OLD,G_NEW)}.items():
        assert s.count(o)==1, (path,name)
        s = s.replace(o,n,1)
    ast.parse(s)
    open(path,'w').write(s)
    print('v2 patched', path)
