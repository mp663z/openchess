# T0353 incremental-mutator resume validation (author-run, /tmp/wi-restart)

Observed sequence this run (all times IST, Oct 25):
1. Pre-patch run wrote /tmp/ires-restart.tsv lines 1-8 (mutants 1-8), then the
   process was killed mid-mutant-8 for the incremental patch.
2. `git checkout server/` restored the production file, relaunch with same MOUT
   printed 8 resume-skip lines and continued; TSV grew to 10. Uniqueness check:
   10/10 unique on (lineno,before,after); no duplicate execution recorded.
3. Killed again at 12 lines for the fingerprint-guard patch; relaunched; resumed
   from 12; sweep currently running.
4. Stale-input refusal demonstrated (exit=2):
   MROOT=/tmp/wi-restart/ MOUT=/tmp/demo.tsv  # demo.tsv.fp contained a wrong hash
   -> stderr: "STALE-TSV: inputs changed since the results file was written;
      refusing to resume" with recorded vs current fingerprints; exit code 2.
   Current fingerprint at demonstration: 
   6a0223406b9535fdc04556bc8ef35dc763c9ad220367b88a0b9bdc7484a714e3  (server/jobs_restart.py in /tmp/wi-restart)
   775000be43314cbf746e21c104f6a763e0e110575642ee356c0b4c54bd345e9e  (tests/test_t0353_restart_integration_restart.py)
   562a30c06e5c184057e2eb9249d12526601acb4dc8071e50fe36adb82338708f  (mut_all.py itself)

Guard semantics (mut_all.py / mut_extra.py, see diffs):
- Fingerprint = sha256 of production file + each test file + the mutator script.
- Sidecar: <MOUT>.fp. If MOUT exists and sidecar mismatches: refuse (exit 2).
  If MOUT exists and no sidecar: adopt (write sidecar). Fresh run: write sidecar.
- Resume skip is exact (lineno,before,after) match against recorded TSV rows.
- A stale mutated production file also trips the guard because its hash changes.

Coverage/resume claims remain author-run pending owner independent execution.
