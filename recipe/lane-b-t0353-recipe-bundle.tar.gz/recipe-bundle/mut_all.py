import re,subprocess,sys,shutil,os
mod,tests=sys.argv[1],sys.argv[2:]
import os
root=os.environ.get("MROOT","/home/sandbox/openchess/")
p=root+f"server/{mod}.py"
src=open(p).read().split("\n")
import hashlib
def _sha(path):
    return hashlib.sha256(open(path,"rb").read()).hexdigest()
fp=";".join([_sha(p)]+[_sha(t if os.path.isabs(t) else os.path.join(root,t)) for t in tests]+[_sha(os.path.abspath(__file__))])
mout=os.environ.get("MOUT")
fp_path=mout+".fp" if mout else None
if mout:
    if os.path.exists(mout):
        if os.path.exists(fp_path):
            old=open(fp_path).read().strip()
            if old!=fp:
                sys.stderr.write("STALE-TSV: inputs changed since the results file was written; refusing to resume\n")
                sys.stderr.write(f"recorded {old}\ncurrent  {fp}\n")
                sys.exit(2)
        else:
            open(fp_path,"w").write(fp)
    else:
        open(fp_path,"w").write(fp)
swaps=[("<=","<"),(">=",">"),(" < "," <= "),(" > "," >= "),("==","!="),("!=","=="),(" and "," or "),(" or "," and "),
("return False","return True"),("return True","return False"),("is None","is not None"),("is not None","is None"),
("+ 1","+ 0"),("- 1","- 0"),("not ","")," ".join([""]*1) and ("min(","max("),("max(","min("),("//","*"),(" * "," + "),("ensure_ascii=True","ensure_ascii=False"),(" - "," + "),(" + "," - "),(" * "," // "),(" // "," * "),(" * "," - "),("**","*"),("%","//")]
swaps=[x for x in swaps if isinstance(x,tuple)]
start=next(i for i,l in enumerate(src) if l.startswith("_CC ="))
indoc=False
mout=os.environ.get("MOUT")
done=set()
if mout and os.path.exists(mout):
    for _line in open(mout):
        _p=_line.rstrip("\n").split("\t")
        if len(_p)>=4: done.add((int(_p[0]),_p[2],_p[3]))
def emit(i,l,nl,status,detail):
    if not mout: return
    detail=str(detail).replace("\t"," ").replace("\n"," ")[:80]
    with open(mout,"a") as f:
        f.write(f"{i+1}\t{status}\t{l.strip()}\t{nl.strip()}\t{detail}\n")
        f.flush(); os.fsync(f.fileno())
surv=[];tot=0;crash=[];sem=0
for i in range(start,len(src)):
    l=src[i]
    st=l.strip()
    if indoc:
        if '"""' in st: indoc=False
        continue
    if st.startswith('"""'):
        if not (st.count('"""')>=2): indoc=True
        continue
    if st.startswith("#"): continue
    code=l.split("  # ")[0]
    cands=list(swaps)
    l=code
    for m in re.finditer(r"(?<![\w.])(\d+)(?![\w.])",l):
        v=int(m.group(1))
        if not l.strip().startswith(("from","import")):
            if v>1: cands.append((m.group(1),str(v+1)));cands.append((m.group(1),str(v-1)))
            else:
                cands.append((m.group(1),str(v+1)));cands.append((m.group(1),str(v+2)))
                if v==1: cands.append((m.group(1),"0"))
    cands+=[("2**53 - 1","2**53 - 2"),("2**53 - 2","2**53 - 1")]
    for a,b in cands:
        for m in re.finditer(re.escape(a),l):
            nl=l[:m.start()]+b+l[m.end():]
            if nl==l: continue
            tot+=1
            if (i+1,l.strip(),nl.strip()) in done: continue
            new=src[:i]+[nl]+src[i+1:]
            open(p,"w").write("\n".join(new))
            subprocess.run("find . -name __pycache__ -prune -exec rm -rf {} +",shell=True,cwd=root,capture_output=True)
            r=subprocess.run(["/tmp/v/bin/python","-m","pytest","-q","-x","-p","no:cacheprovider"]+tests,cwd=root,capture_output=True,text=True)
            if r.returncode==0:
                surv.append((i+1,l.strip(),nl.strip())); emit(i,l,nl,"survivor","")
            else:
                errs=[x for x in r.stdout.splitlines() if x.startswith("E  ")]
                first=errs[0][1:].strip() if errs else ""
                import re as _re
                if _re.match(r"^(TypeError|KeyError|AttributeError|IndexError|ValueError|RecursionError|NameError|ZeroDivisionError|OverflowError|UnicodeError|RuntimeError|UnicodeEncodeError|UnicodeDecodeError)\b",first):
                    crash.append((i+1,nl.strip(),first[:80])); emit(i,l,nl,"crash",first)
                else:
                    sem+=1; emit(i,l,nl,"killed",first)
open(p,"w").write("\n".join(src))
if mout and os.path.exists(mout):
    rows=[_l.rstrip("\n").split("\t") for _l in open(mout) if _l.strip()]
    rows=[_r for _r in rows if len(_r)>=4]
    sa=[_r for _r in rows if _r[1]=="survivor"]; ca=[_r for _r in rows if _r[1]=="crash"]; ka=[_r for _r in rows if _r[1]=="killed"]
    print("mutants",len(rows),"survivors",len(sa),"semantic_kills",len(ka),"crash_only",len(ca))
    for _r in ca: print("CRASH",(int(_r[0]),_r[3],_r[4] if len(_r)>4 else ""))
    for _r in sa: print((int(_r[0]),_r[2],_r[3]))
else:
    print("mutants",tot,"survivors",len(surv),"semantic_kills",sem,"crash_only",len(crash))
    for c in crash: print("CRASH",c)
    for s in surv: print(s)
