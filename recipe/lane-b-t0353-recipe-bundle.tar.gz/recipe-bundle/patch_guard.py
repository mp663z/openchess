import sys, ast

ANCHOR = '''src=open(p).read().split("\\n")
'''
NEW = '''src=open(p).read().split("\\n")
import hashlib
def _sha(path):
    return hashlib.sha256(open(path,"rb").read()).hexdigest()
fp=";".join([_sha(p)]+[_sha(t) for t in tests]+[_sha(os.path.abspath(__file__))])
mout=os.environ.get("MOUT")
fp_path=mout+".fp" if mout else None
if mout:
    if os.path.exists(mout):
        if os.path.exists(fp_path):
            old=open(fp_path).read().strip()
            if old!=fp:
                sys.stderr.write("STALE-TSV: inputs changed since the results file was written; refusing to resume\\n")
                sys.stderr.write(f"recorded {old}\\ncurrent  {fp}\\n")
                sys.exit(2)
        else:
            open(fp_path,"w").write(fp)
    else:
        open(fp_path,"w").write(fp)
'''
for path in sys.argv[1:]:
    s = open(path).read()
    assert s.count(ANCHOR) == 1, path
    s = s.replace(ANCHOR, NEW, 1)
    ast.parse(s)
    open(path, 'w').write(s)
    print('guard patched', path)
