import sys, ast

HEAD_ANCHOR = "indoc=False\nsurv=[];tot=0;crash=[];sem=0\n"
HEAD_NEW = '''indoc=False
mout=os.environ.get("MOUT")
done=set()
if mout and os.path.exists(mout):
    for _line in open(mout):
        _p=_line.rstrip("\\n").split("\\t")
        if len(_p)>=4: done.add((int(_p[0]),_p[2],_p[3]))
def emit(i,l,nl,status,detail):
    if not mout: return
    detail=str(detail).replace("\\t"," ").replace("\\n"," ")[:80]
    with open(mout,"a") as f:
        f.write(f"{i+1}\\t{status}\\t{l.strip()}\\t{nl.strip()}\\t{detail}\\n")
        f.flush(); os.fsync(f.fileno())
surv=[];tot=0;crash=[];sem=0
'''

SKIP_ANCHOR = """            if nl==l: continue
            tot+=1
"""
SKIP_NEW = """            if nl==l: continue
            tot+=1
            if (i+1,l.strip(),nl.strip()) in done: continue
"""

TAIL_ANCHOR = '''            if r.returncode==0: surv.append((i+1,l.strip(),nl.strip()))
            else:
                errs=[x for x in r.stdout.splitlines() if x.startswith("E  ")]
                first=errs[0][1:].strip() if errs else ""
                import re as _re
                if _re.match(r"^(TypeError|KeyError|AttributeError|IndexError|ValueError|RecursionError|NameError|ZeroDivisionError|OverflowError|UnicodeError|RuntimeError|UnicodeEncodeError|UnicodeDecodeError)\\b",first):
                    crash.append((i+1,nl.strip(),first[:80]))
                else:
                    sem+=1
open(p,"w").write("\\n".join(src))
print("mutants",tot,"survivors",len(surv),"semantic_kills",sem,"crash_only",len(crash))
for c in crash: print("CRASH",c)
for s in surv: print(s)
'''
TAIL_NEW = '''            if r.returncode==0:
                surv.append((i+1,l.strip(),nl.strip())); emit(i,l,nl,"survivor","")
            else:
                errs=[x for x in r.stdout.splitlines() if x.startswith("E  ")]
                first=errs[0][1:].strip() if errs else ""
                import re as _re
                if _re.match(r"^(TypeError|KeyError|AttributeError|IndexError|ValueError|RecursionError|NameError|ZeroDivisionError|OverflowError|UnicodeError|RuntimeError|UnicodeEncodeError|UnicodeDecodeError)\\b",first):
                    crash.append((i+1,nl.strip(),first[:80])); emit(i,l,nl,"crash",first)
                else:
                    sem+=1; emit(i,l,nl,"killed",first)
open(p,"w").write("\\n".join(src))
if mout and os.path.exists(mout):
    rows=[_l.rstrip("\\n").split("\\t") for _l in open(mout) if _l.strip()]
    rows=[_r for _r in rows if len(_r)>=4]
    sa=[_r for _r in rows if _r[1]=="survivor"]; ca=[_r for _r in rows if _r[1]=="crash"]; ka=[_r for _r in rows if _r[1]=="killed"]
    print("mutants",len(rows),"survivors",len(sa),"semantic_kills",len(ka),"crash_only",len(ca))
    for _r in ca: print("CRASH",(int(_r[0]),_r[3],_r[4] if len(_r)>4 else ""))
    for _r in sa: print((int(_r[0]),_r[2],_r[3]))
else:
    print("mutants",tot,"survivors",len(surv),"semantic_kills",sem,"crash_only",len(crash))
    for c in crash: print("CRASH",c)
    for s in surv: print(s)
'''

for path in sys.argv[1:]:
    s = open(path).read()
    assert s.count(HEAD_ANCHOR) == 1, (path, 'head')
    assert s.count(SKIP_ANCHOR) == 1, (path, 'skip')
    assert s.count(TAIL_ANCHOR) == 1, (path, 'tail')
    s = s.replace(HEAD_ANCHOR, HEAD_NEW).replace(SKIP_ANCHOR, SKIP_NEW).replace(TAIL_ANCHOR, TAIL_NEW)
    ast.parse(s)
    open(path, 'w').write(s)
    print('patched', path)
